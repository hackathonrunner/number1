# frozen_string_literal: false
module Psych
  DEFAULT_SNAKEYAML_VERSION = '1.14'.freeze
end
